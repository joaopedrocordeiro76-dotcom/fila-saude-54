# Fila+ Saúde — Pacote pronto (Landing + React App + Simple Webhook)

Arquivos incluídos:
- `index.html` — Landing page estática (Tailwind CDN).
- `react/` — Diretório com app React (Vite) pronto para deploy.
- `server/` — Pequeno servidor Node.js Express para webhooks (ex: Stripe, Twilio) e servir arquivos estáticos.
- `bubble-setup.md` — Guia passo a passo para montar o MVP no Bubble usando a mesma estrutura.
- `deploy-instructions.md` — Instruções para deploy rápido (Netlify, Vercel, Render).

**Como usar (rápido)**:
1. Baixe e extraia o ZIP.
2. A landing (`index.html`) pode ser hospedada diretamente (Netlify/Hostinger/GitHub Pages).
3. Para o React app:
   - `cd react`
   - `npm install`
   - `npm run dev` (desenvolvimento) ou `npm run build` e subir `dist/` para host.
4. Para o servidor Node (webhooks):
   - `cd server`
   - `npm install`
   - criar `.env` a partir de `.env.example`
   - `node server.js` (ou `npm start`)

Se você não manja de programação, eu recomendo:
- Hospedar a `index.html` no Netlify (drag & drop).
- Usar o Bubble para o MVP (guia no arquivo `bubble-setup.md`).
- Usar o servidor apenas quando integrar Twilio/Stripe.

Eu incluí instruções detalhadas em `deploy-instructions.md`. Se quiser, eu já subo tudo pronto para um serviço (ex: Netlify) — me diga qual você prefere e eu te passo os passos GUIADOS linha a linha.
