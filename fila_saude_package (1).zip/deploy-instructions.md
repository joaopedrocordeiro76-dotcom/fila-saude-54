# Deploy rápido (passo a passo)

## Landing (index.html)
- Método simples: Drag & drop do arquivo `index.html` no Netlify (https://app.netlify.com/drop).
- Ou criar um repositório no GitHub e conectar no Netlify/Vercel.

## React App (diretório react/)
- Pré-requisitos: Node.js LTS instalado.
- Commands:
  - `cd react`
  - `npm install`
  - `npm run dev` (rodar localmente)
  - `npm run build` (gera `dist/` para deploy)
- Deploy: conectar repositório ao Vercel/Netlify ou subir a pasta `dist/`.

## Node Server (diretório server/)
- Pré-requisitos: Node.js LTS
- Commands:
  - `cd server`
  - `npm install`
  - criar `.env` baseado em `.env.example` com chaves do Twilio/Stripe
  - `node server.js` (ou usar PM2 / Render / Heroku)

Se quiser, eu te passo os comandos já prontos para executar no seu PC.
