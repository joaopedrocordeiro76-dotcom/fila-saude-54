const express = require('express')
const bodyParser = require('body-parser')
require('dotenv').config()
const app = express()
app.use(bodyParser.json())

// Simple root
app.get('/', (req, res) => res.send('Fila+ Saúde webhook server'))

// Example webhook endpoint (Stripe / Twilio can post here)
app.post('/webhook', (req, res) => {
  console.log('Webhook received:', req.body)
  // TODO: validate signatures in production
  res.json({ received: true })
})

const PORT = process.env.PORT || 3333
app.listen(PORT, () => console.log('Server running on port', PORT))
