# Bubble — Como montar o MVP (passo a passo resumido)

1. Crie uma conta no Bubble (https://bubble.io).
2. Crie um novo aplicativo vazio.
3. Dados (Data):
   - Crie tipos: Paciente, Profissional, Consulta.
   - Campos:
     - Paciente: nome (text), telefone (text), email (text)
     - Profissional: nome (text), especialidade (text), clinica (text)
     - Consulta: paciente (Paciente), profissional (Profissional), datetime (date), tipo (text), status (text)
4. Páginas / UI:
   - Página de agendamento público: formulário que cria uma `Consulta`.
   - Dashboard do profissional: Repeating Group mostrando consultas do dia.
   - Página do paciente: link para reagendar / entrar na fila.
5. Plugins:
   - Install "API Connector" (para Twilio e Zoom)
   - Install Stripe plugin (ou use Redirect para checkout)
6. Workflows:
   - Ao criar `Consulta`: enviar mensagem via Twilio (via API Connector) com link de confirmação.
   - Lembrete (backend workflow): programar evento para 24h antes e 15min antes para enviar mensagens.
7. Teste:
   - Use 2–3 clínicas como beta testers e ajuste mensagens/templates.
8. Observações:
   - Twilio exige verificação do número no trial. Para produção considere Zenvia/Take Blip (no Brasil).
